import React from 'react'

export default function Cart({cart,clearCart,removeFromCart}){
    return(
        <>
        
     
    
     
     {cart.length >0 &&(<button className="clear" onClick={clearCart}>Place Order</button>

     )}
     
     
  
      <div className="products">
      {cart.map((product,idx)=>(
      <div className="product" key={idx}>
      <h3>{product.name}</h3>

       
        <h3>{product.price}</h3>
        <h3>{product.description}</h3>
        <button className="g" onClick={()=>removeFromCart(product)}>Remove</button>
        
        
        
          


        </div>
      ))}



        </div>
        </>
    )
}