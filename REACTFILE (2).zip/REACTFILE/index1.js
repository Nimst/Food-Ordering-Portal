const express=require("express");
const fs=require("fs");
const port=8000;
const app=express();





app.use(express.json());
app.use(express.urlencoded({extended:false}));



   fs.readFile("food.json","utf-8",(err,data)=>{
      const objdata=JSON.parse(data)
      
      app.get("/",(req,res)=>{
      res.send(data);
   })
});

    
    
 
 app.listen(port,()=>console.log('listeng port 8000'));