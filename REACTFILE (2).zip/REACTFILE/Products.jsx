import React,{useState} from 'react'




function Products({ addToCart}){
    const [products] = useState([
      

      {
        category:"Pizza",
          name:"Tomato Basil Italian Pizza",
          image:"https://res.cloudinary.com/dg2wcmh81/image/upload/v1617100795/3_qvzdfe.jpg",
          
          price:450,
          description:"Dressed with garlic cloves"
        },
        {category:"Pizza",
          name:"Bombay Pizza",
          image:"https://res.cloudinary.com/dg2wcmh81/image/upload/v1617101779/4_fmes8a.jpg",
          price:550,
          description:"Spicy tomato sauce with mushrooms"
        },
        {category:"Pizza",
          name:"Sicilla Pizza",
          image:"https://res.cloudinary.com/dg2wcmh81/image/upload/v1617101826/5_ceev4h.jpg",
          price:450,
          description:"A thick base pizza with fresh tomato sauce"
        }
    
        
       
                ]);
     
      
    
    return(
        <>
  
  
        <h1 className="c">Tasty Pizzas</h1>
        <div className="products">
        {products.map((product,idx)=>(
        <div className="product" key={idx}>
        <h3 className="d">{product.name}</h3>
  
          <img src={product.image} className="pic1"/>
          <h3 className="e">{product.price}</h3>
          <h3 className="f">{product.description}</h3>
          <button className="order" onClick={()=> addToCart(product)}>Order Now</button>
          
          </div>

      
      
      
      ))}
     
    </div>
    </>
  );
           
}
export default Products;